<?php
include_once "db.php";
$search_string = $_GET['searchValue'];

$query = "SELECT * FROM `cities` WHERE `name` LIKE '%$search_string%' OR `state` LIKE '%$search_string%' ";
$result = mysqli_query($connection, $query);

while ($row = mysqli_fetch_assoc($result)) { ?>
<option value="<?= $row['name'] ." - ". $row['state'] ?>"></option>
<?php }
?>